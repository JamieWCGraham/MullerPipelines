function [metadata] = get_3D_ML_metadata(taskstruct, row_idx)

%
% GET MONKEY (BEHAVIORAL) LAB TRIAL TIME AND ID
% 27 August 2019
%
% PARAMETERS
% taskstruct - raw behavioral data (.mat)
% row_idx - row number
%
% OUTPUTS
% metadata - behavioral trials time, outcome and ID
%

% get reference to trial structure
tmp = fieldnames(taskstruct.Trials); tmp = tmp{row_idx,1};
data = eval( sprintf( 'taskstruct.Trials.%s', tmp ) );

% parse metadata
if ~strcmpi('userStoppedTrial', data.OutcomeWord) &&  isfield(data,'Encoding_ST') &&  isfield(data,'Encoding_ET') &&  isfield(data,'Delay_ST')
    trial_time = nan( 1, 7 );
    trial_time(1) = data.SOT_Time;
    trial_time(2) = data.Encoding_ST;
    trial_time(3) = data.Encoding_ET;
    trial_time(4) = data.Delay_ST;
    assert( trial_time(3) == trial_time(4), 'assertion failed' )
    trial_time(5) = data.Delay_ET;
    nav_start_time = find( cellfun( @(x) strcmp( x, 'OnStart' ), data.Unreal_States ) == 1, 1, 'first' );
    tmp_idx = find( cellfun( @(x) strcmp( x, data.GoalID ) | strcmp( x, 'OnBlackWalking' ) | ...
        strcmp( x, 'OnBlackStatic' ), {data.Unreal_States{nav_start_time+1:end}} ) == 1, 1, 'first' );
    if ~isnan(tmp_idx)
        trial_time(6) = data.Unreal_Times(tmp_idx  + nav_start_time );
    else
        % set end of searching period to last recorded time in unreal_state
        trial_time(6) = data.Unreal_Times(size({data.Unreal_States{nav_start_time+1:end}},2)  + nav_start_time );
    end
    trial_time(7) = data.EOT_Time;
else
    trial_time = nan( 1, 7 );
    trial_time(1) = data.SOT_Time;
    trial_time(7) = data.EOT_Time;
end

% save metadata
metadata.trialID = tmp;
metadata.trial_time = trial_time;
metadata.goal = data.GoalID;
metadata.outcome = data.OutcomeWord;

end
