function [params] = merge_trial_metadata(params, taskstruct, nevfilename, user_inputs)

%
% MERGE CEREBUS AND BEHAVIORAL TRIAL DATA
% 26 August 2019
%
% PARAMETERS
% params.subject - monkey name (buzz/theo)
% params.session - session date (yyyymmdd)
% taskstruct - raw behavioral data (.mat)
% nevfilename - raw spike data which has the trial time such as encoding and
% delay times (it is usually in the dorsal array spike data (nsp1) )
%
% OUTPUTS
% trial_time - behavioral and cerebus trial time (SOT_time, Encoding_ST,
% Encoding_ET, Delay_ST, Delay_ET, Goal, EOT_time, Cerebus_ST, Cerebus_ET)
% trial_outcome - trial outcome (Correct/Time Run Out)
% trial_ID - trial unique ID
%


% load behavioral data
for ii = 1:size(nevfilename,1)  % if there are more than one nevfiles
    clearvars -except ii params taskstruct nevfilename row_idx user_inputs
    
    if strcmp(params.exp_type, "ODR")
        T = load( taskstruct(ii) ); T = eval( 'T.taskStruct' );
    else
        T = load( taskstruct ); T = eval( 'T.taskStruct' );
    end

    % number of trials
    num_trial = numel(fieldnames(T.Trials));
    
    % build trials metadata
    if ii == 1
        params.trial_time = [];
        row_idx = 0;
    end

    disp(nevfilename)
    
    % get cerebus metadata from nev file (nsp1/dorsal channel)
    C_metadata = get_cerebus_metadata(params, nevfilename(ii, :));
    
    trlwaitbar = waitbar(0,'Computing trials time');
    for ind = 1:num_trial
        
        % Progress bar
        waitbar(ind/num_trial,trlwaitbar);
        
        % Get monkey lab trial metadata

        ML_metadata = get_3D_ML_metadata(T, ind);
        
        % Get corresponding row index in cerebus metadata
        trial_idx = find(contains(C_metadata.trialID,ML_metadata.trialID));
        
        % if the trial exists in both cerebus and ML data
        if ~isempty(trial_idx) &  ~any(isnan(ML_metadata.trial_time))
            
            row_idx = row_idx + 1;
            params.trial_time = [params.trial_time; ML_metadata.trial_time ...
                C_metadata.trial_time(trial_idx,:)];
            if isfield(ML_metadata, 'goal'); params.trial_goal{row_idx} = ML_metadata.goal; end
            if isfield(ML_metadata, 'TargPos'); params.trial_target_pos{row_idx} = ML_metadata.TargPos; end
            if isfield(ML_metadata, 'FixPos'); params.trial_fix_pos{row_idx} = ML_metadata.FixPos; end
            params.trial_outcome{row_idx} = ML_metadata.outcome;
            params.trial_ID{row_idx} =  ML_metadata.trialID;
            
            params.file_number{row_idx} = ii;
            
        end
    end
    
    close(trlwaitbar);
    
end

    % Sort trial_time

    disp(size(params.trial_time))
    [~, idx] = sort(params.trial_time(:,1), 1);



    params.trial_time = params.trial_time(idx, :);
    if isfield(params, 'trial_goal'); params.trial_goal = params.trial_goal(idx); end
    if isfield(params, 'trial_target_pos'); params.trial_target_pos = params.trial_target_pos(idx); end
    if isfield(params, 'trial_fix_pos'); params.trial_fix_pos = params.trial_fix_pos(idx); end
    params.trial_outcome = params.trial_outcome(idx);
    params.trial_ID = params.trial_ID(idx);
    params.file_number = params.file_number(idx);

end