function [metadata] = load_wm1_rawdata(params, root_dir,user_inputs)

%
% LOAD RAW WM1 AND EXTRACT TRIAL METADATA, SPIKE AND LFP DATA
% 27 August 2019
%
% PARAMETERS
% params.subject - monkey name (buzz/theo)
% params.session - session date (yyyymmdd)
% params.nbr_sec - number of sections required to read lfp data (.ns6)
% params.Fs - sampling rate after down sampling
% root_dir - root directory of raw and output data
%
% OUTPUTS
% metadata - trail metadata (time, outcome & ID)
% data - individual processed trial lfp and spike data
%

% 1. INITIALIZING PARAMETERS 

params.srate = 30000;                   % This is the sampling rate at which we sample our LFP data (# of samples per second)
ds_factor = params.srate / params.Fs;   % We downsample for computational efficiency (essentially we use less of our recorded data). This is the factor by which we downsample


% 2. SETTING DIRECTORIES

% We need to set appropriate directory pathways to access the CEREBUS data (raw neural LFP data) and the
% Monkey Lab data (behavioural data). We also must set the .nev file name that is to be loaded..


ml_data_dir = "./BehavData";
nevfilename = sprintf('./RawData/%d_NSP%d_00%d.nev',user_inputs.recording_date,1,user_inputs.task_number);

% Here we are setting and making an output directory for our output for
% this code.

output_dir = sprintf('%s/processed/%s/%s', root_dir(2), params.subject, params.session);
mkdir(output_dir)

% Here we are setting the behavioural file names and directory

if user_inputs.task_number == 1
    taskstruct = sprintf('./BehavData/%s_%s_KeyMapWM.mat',user_inputs.subject_name,params.session) ;
else
    taskstruct = sprintf('./BehavData/%s_%s_KeyMap.mat',user_inputs.subject_name,params.session);
end     


% 3. MERGE BEHAVIOURAL DATA

% For this pipeline, there are two sources of recorded data for a given
% experimental session. The first source of data is CEREBUS data, and
% includes the raw LFP data, as well as LFP spike data, timestamps,
% neuron-unit data, etc. The second source of data is from the Monkey
% Lab Machine (MLM). This data contains all the metadata for the given session, and also 
% all the behavioural data. By 'behavioural data', we mean information 
% such as the timestamps for 'start' and 'stop' times for various 
% behavioural tasks in a given experimental session. 

% Here we are going to merge the trial metadata from the CEREBUS and ML
% machine

params = merge_trial_metadata(params, taskstruct, nevfilename, user_inputs);

% Now that the metadata is merged, we can finally load all the data into our MATLAB workspace

% 4. LOADING DATA FOR BOTH VENTRAL AND DORSAL ARRAYS 

% The data acquisition process involves two intracranial arrays of
% electrodes for the monkey brain, one ventral and one dorsal. 

% nsp = 0 is ventral electrode array 
% nsp = 1 is dorsal electrode array 


for nsp = 0:1           % this is iterating over the types of electrode arrays used in the experiment.

    % First, we pass our subject 'name of monkey', nsp value, and root
    % directory into the function ch_mapping.m and store the output as
    % the variable channel_map.

    channel_map = ch_mapping(params.subject, nsp, root_dir(1),user_inputs);  % Look at the function ch_mapping.m in 'input folder' 
    
    % This code block is just naming neural file names for .nev and .ns6
    % files.
   
     nevfilename = sprintf('./RawData/%d_NSP%d_00%d.nev',user_inputs.recording_date,nsp,user_inputs.task_number);
     nsxfilename = sprintf('./RawData/%d_NSP%d_00%d.ns6',user_inputs.recording_date,nsp,user_inputs.task_number);


    % 5. LOADING SPIKE DATA

    % We have .nev files, which contain spike data from CEREBUS
    % We also have .ns6 files, which contain the raw LFP data from CEREBUS, split into 6 chunks because the raw data is so large.
    
    % Here we load .nev file spike data 

    spike_data = load_spike_data(nevfilename, params);   % look in 'input' folder for load_spike_data.m
    
    for ii = 1:size(nsxfilename,1)       % this is a for loop over all ns6 files (sometimes there is more than one due to stop and starting of the experiment)       

        %   Sometimes there are false starts, or insignificant files at the
        %   beginning of the ns6 files, we need to make sure to omit them
        %   if they are present. That is what lfp_offset does.

        offset = lfp_offset(nsxfilename(ii,:));         % look in 'input' folder for lfp_offset.m
        
        % if there exists 'extra' information at the beginning of the ns6
        % file to be discarded, offset just tells us where to start
        % actually processing the ns6 file.

        chwaitbar = waitbar(0,'Processing trial data');         % Implement a loading bar 
        
        for sec = 1:params.nbr_sec              % Iterating over all 6 chunks of the ns6 file
            
            % Here, we are getting the indices of the start and end
            % behavioural times in a given chunk of the data. 
            
            [start_idx, end_idx, trial_idx] = trial_group_time(params, sec, offset, ii); % see 'input' folder for trial_group_time.m

            % start_idx is an integer that indexes the start time of the first trial in the raw
            % data chunk

            % end_idx is an integer that indexes the end time of the last trial in the raw data
            % chunk

            % trial_idx is an array of two indices start_idx and end_idx.

            if isempty(start_idx); continue; end  % this basically says, if there is no start and end trial data, then skip this chunk of the ns6 file
            
            % Progress bar
            waitbar(sec/params.nbr_sec,chwaitbar);
            
            % Here we are loading the given chunk of LFP data at this point in the for loop    (.ns6)
            clear tmp_lfp;
            tmp_lfp = openNSx(nsxfilename(ii,:), sprintf('t:%d:%d',start_idx,end_idx));    % temporary lfp data for this chunk
            
            % Find Channel Row 
            ch_row = arrayfun(@(y) find(cell2mat(cellfun(@(x) x==y,{tmp_lfp.ElectrodesInfo.ElectrodeID},'Uni',0)) == 1), 1:100, 'un', 0);
            tmp_lfp = tmp_lfp.Data;     
            
            for tr = trial_idx(1):trial_idx(2)      % Iterating over trials inbetween the start and end of this portion of the lfp data. 
                
                tr_start_time = floor(params.trial_time(tr, 8) * params.srate);  % converting the start index to start time 
                tr_end_time = floor(params.trial_time(tr, 9) * params.srate);    % converting the end index to end time 
                
                if tr == trial_idx(1), time_offset = tr_start_time - 1; end   % here we are computing a one minute time offset from the beginning of the trial data 
                
                % Now we will check trial time. We need to make sure that
                % the trial times of each of the sucessive data points are
                % in consecutive order, otherwise we have an error in our acquisition. Sometimes this screws up in the
                % acquisition, and if so.. then we need to simply discard
                % this trial and move onto the next trial. 

                if params.trial_time(tr, 1) > params.trial_time(tr, 2) || ...
                        params.trial_time(tr, 2) > params.trial_time(tr, 3) || ...
                        params.trial_time(tr, 3) > params.trial_time(tr, 4) || ...
                        params.trial_time(tr, 4) > params.trial_time(tr, 5) || ...
                        params.trial_time(tr, 5) > params.trial_time(tr, 6) || ...
                        params.trial_time(tr, 6) > params.trial_time(tr, 7) || ...
                        (params.trial_time(tr, 6) - params.trial_time(tr, 1)) > ... % duration of cerebus recording vs ML recording
                        (params.trial_time(tr, 9) - params.trial_time(tr, 8))
                    continue;
                end
                
                % Variable initialization below 

                spike = []; % spike data
                lfp = nan( 10, 10, (tr_end_time-tr_start_time + 1) );   % lfp data 
                lfp_d = nan( 10, 10, ceil(double(tr_end_time-tr_start_time + 1)/double(ds_factor)) );   % this is the lfp data downsampled
                
                % Isolating a Subset of Trial Data 
                col_index = find(spike_data.TimeStamp >= tr_start_time & spike_data.TimeStamp <= tr_end_time);   % finding the indices of spike data that is after the start time and before the end time of the trial 
                
                % Here we are populating tmp_spike fields to eventually
                % store in spike variable
                tmp_spike.TimeStamp = spike_data.TimeStamp(col_index)-tr_start_time + 1;
                tmp_spike.Electrode = spike_data.Electrode(col_index);
                tmp_spike.Unit = spike_data.Unit(col_index);
                tmp_spike.Waveform = spike_data.Waveform(:, col_index);


                % This next block of code iteratively populates the spike
                % variable, electrode by electrode on the array. The double
                % for loop iterates over all elements in the channel map
                % array. The (rr,cc)'th electrode corresponds to the
                % electrode in the rr'th row, and cc'th column of the
                % channel map matrix. 
                
                for rr = 1:10
                    for cc = 1:10

                        % Make sure that channel_map is nonempty and filled with integer vales
                        
                        if isnan( channel_map(rr,cc) ); continue; end   
                        if isempty(ch_row{channel_map(rr,cc)}); continue; end
                        
                        % Find all indices of our temporary spike data that
                        % have electrodes corresponding to the loop tuple
                        % (rr,cc). 
          
                        col_index = find(tmp_spike.Electrode==channel_map(rr,cc));
                        
                        % We are now downsampling the spike timestamps, and
                        % populating the spike variable. 

                        if ~isnan(col_index)
                            spike{rr,cc}.TimeStamp = floor(double(tmp_spike.TimeStamp(col_index))/double(ds_factor))';
                            spike{rr,cc}.Unit = tmp_spike.Unit(col_index)';
                            spike{rr,cc}.Waveform = tmp_spike.Waveform(:, col_index)';
                        else
                            spike{rr,cc}.TimeStamp = [];
                            spike{rr,cc}.Unit = [];
                            spike{rr,cc}.Waveform = [];
                        end
                        
                        % Populating the LFP data with the (rr,cc)'th electrodes lfp data. 
                        lfp(rr, cc, :) = tmp_lfp(ch_row{channel_map(rr,cc)}, (tr_start_time - time_offset):(tr_end_time- time_offset));
                        % Populating the downsampled LFP data with the (rr,cc)'th electrodes lfp data. 
                        lfp_d(rr,cc,:) = resample(squeeze(lfp(rr,cc,:)),1,ds_factor);
                    end
                end


                % Now we are storing our fully populated spike variable in
                % the field 'spike' of the data struct. We do the same with
                % the lfp downsampled variable lfp_d. 

                data.spike = spike;
                data.lfp = lfp_d;
                data.metadata.trial_ID = params.trial_ID(tr);   % storing metadata of a given trial 

                % Now we save further metadata...
                if isfield(params, 'trial_goal'); data.metadata.trial_goal = params.trial_goal(tr); end
                if isfield(params, 'trial_target_pos'); data.metadata.trial_target_pos = params.trial_target_pos(tr); end
                if isfield(params, 'trial_fix_pos'); data.metadata.trial_fix_pos = params.trial_fix_pos(tr); end
                data.metadata.trial_outcome = params.trial_outcome(tr);
                data.metadata.trial_time = params.trial_time(tr, :);
                data.metadata.file_number = params.file_number(tr);
                if params.task_number_final == 1
                    save(sprintf('%s/%s_wm_%s_nsp%d_tr%d.mat', output_dir, params.subject, params.session, nsp, tr), 'data');
                else
                    save(sprintf('%s/%s_%s_nsp%d_tr%d.mat', output_dir, params.subject, params.session, nsp, tr), 'data');
                end
                clear data lfp lfp_d;
                
            end
        end
    end
        
        close(chwaitbar);   % close waitbar.
end
    

% Here we are simply saving all our metadata in a file designated here below: 

metadata = params;
save(sprintf('%s/metadata_wm_%s_%s.mat', output_dir, params.subject, params.session), 'metadata');


end


