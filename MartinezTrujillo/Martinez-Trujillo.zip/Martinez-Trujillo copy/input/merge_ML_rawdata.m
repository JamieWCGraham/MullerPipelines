function [flag] =  merge_ML_rawdata(params, root_dir)

%
% MERGE BEHAVIORAL(MONKEY LAB) DATA
% 13 September 2019
%
% PARAMETERS
% params.subject - monkey name (buzz/theo)
% params.session - session date (yyyymmdd)
% root_dir - root directory for raw and processed data
%
% OUTPUTS
% taskStruct - monkey lab (behavioral) data
%



% SET DIRECTORY

% Here we are setting the directories of the MATLAB workspace so that we can merge our files. You will have to change this part of 
% the code for your individual file directory pathway


if ~ismember(params.session, {'20170616', '20170705', '20170717'})
    data_dir = 'BehavData/Misc';
    files = dir( sprintf( '%s/*.mat', data_dir ) );
    files = files(startsWith({files.name}, sprintf('T_%s_KeyMapWM', params.session)));
else
    data_dir = 'BehavData/Misc';
    files = dir( sprintf( '%s/*.mat', data_dir ) );
    files = files(startsWith({files.name}, sprintf('T_%s_KeyMapWM', params.session)));
end 


% MERGE. Here we are merging the data


if ~isempty(files)                                                  % If the above behavioural ML files have been appropriately loaded into the workspace, therefore directories have been set properly..
    c= []; fname = [];                                              % initialize c and fname lists. 
    for ff = 1:length(files)                                        % Iterate through all files (loop variable ff)
        tmp = load(sprintf('%s/%s', data_dir, files(ff).name));     % load the ff'th file and set as temporary variable temp
        tmp = tmp.taskStruct;                                       % set this temporary variable temp to the taskStruct field. 
        c = [c;struct2cell(tmp.Trials)];                            % here we are iteratively storing the behavioural data trials in this c list variable
        fname = [fname; fieldnames(tmp.Trials)];                    % here we are iteratively storing the names of the behavioural trials. 
    end
    taskStruct = struct();                                          % initialize a taskstruct to contain all info
    taskStruct.SessionInfo = tmp.SessionInfo;                       % this taskStruct field contains all the session info 
    taskStruct.Trials = cell2struct(c, fname, 1);                   % saves c and fname data as a trials 'struct'.         
    
    % make output directory
    output_dir = sprintf( '%s/processed/%s/%s', root_dir(2), params.subject, params.session );      % Here we are linking all this behavioural data with the raw data by storing 
    mkdir(output_dir);
    
    % save merged file
    %save( sprintf( '%s/B_%s_KeyMapWM.mat', output_dir, params.session), 'taskStruct');           % Here we are saving the taskStruct (behavioural data) amongst the raw data files.   
    
    flag = 1;
else
    flag = 0;
end

end