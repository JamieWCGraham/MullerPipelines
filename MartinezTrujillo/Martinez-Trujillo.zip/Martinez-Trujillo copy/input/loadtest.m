
% Navigate your current folder to Martinez-Trujillo then run this code

trial_num = input("Enter Desired Trial Number: ");
filename = sprintf("./output/processed/buzz/20171127/buzz_wm_20171127_nsp0_tr%d.mat",trial_num);
lfp = load(filename);