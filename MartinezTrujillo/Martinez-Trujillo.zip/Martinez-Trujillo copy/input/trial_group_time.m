function [start_idx, end_idx, trial_idx] = trial_group_time(params, sec, offset, ii)

% GET START AND END OF ROW INDEX AND TIME CORRESPONDS TO THE GROUP OF TRIALS
% 27 August 2019
%
% PARAMETERS
% params.trial_time - trials metadata
% sec - current section number
% params.nbr_sec - total number of sections used for reading raw lfp data (.ns6)
% params.srate - original sampling rate
% offset - number of records which should be discarded at the beginning of
% ii - file number
% raw lfp data
% 
% OUTPUTS
% start_idx - row index corresponds to trial start time of first trial in
% the group
% end_idx - row index corresponds to trial end time of last trial in the
% group
% trial_idx - array of all trials number in the current section
% 

ind_file = find(cell2mat(params.file_number) == ii);
tmp_trial_time = params.trial_time(ind_file, :);
% trials number and row index

start_idx = (sec-1) * floor(size(tmp_trial_time,1)/params.nbr_sec) + 1;
    if sec == params.nbr_sec
        end_idx = size(tmp_trial_time,1);
    else
        end_idx = (sec) * floor(size(tmp_trial_time,1)/params.nbr_sec);
    end
    trial_idx = [start_idx, end_idx];

    start_idx = floor((tmp_trial_time(start_idx, 8)) * params.srate + offset);
    end_idx = floor((tmp_trial_time(end_idx, 9)) * params.srate + offset);

if ii > 1
    trial_idx = trial_idx + find(cell2mat(params.file_number) == ii-1, 1, 'last');
end

end
