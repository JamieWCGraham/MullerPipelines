function [metadata] = get_cerebus_metadata(params, nevfilename)

% GET CEREBUS TRIAL TIME AND ID
% 27 August 2019
%
% PARAMETERS
% params.subject - monkey name (buzz/theo)
% nevfilename - raw spike data (.nev)
%
% OUTPUTS
% metadata - cerebus trials time and ID
%

% Time delay between cerebus and ML computers
MLtoCer_ComTime = 0.008;

% load spike data
O = openNEV( nevfilename, 'nosave', 'nomat');

% retrive event time and event digital words
event_word = O.Data.SerialDigitalIO.UnparsedData;
event_time = O.Data.SerialDigitalIO.TimeStampSec;

trial_time = [];
temp_TrialID = [];
 % build trials' ID
    temp_TrialID = [find(event_word == 1018)+1, find(event_word == 1019)-1];
    temp_TrialID = arrayfun(@(x) num2str(event_word(temp_TrialID(x,1):temp_TrialID(x,2))', ...
        '%03d'), (1:size(temp_TrialID,1)), 'Uni', false);
    trialID = cellfun(@(x)['ID_' x], temp_TrialID, 'uni', false)';
    % get trials start and end


%     This block of code below simply forces the vectors temp_start and temp_end defined below to have the same length so that they
%     can be concatenated in trial_time

    temp_start = event_time(find(event_word == 1016))';
    temp_end = event_time(find(event_word == 1017))';

    if length(temp_start) == length(temp_end)
    %     do nothing
    elseif length(temp_start) > length(temp_end)
        temp_start = temp_start(1:(end-(length(temp_start)-length(temp_end))));
    else
        temp_end = temp_end(1:(end-(length(temp_end)-length(temp_start))));
    end
    
    trial_time = [temp_start,temp_end];


% save metadata
metadata.trialID = trialID;
metadata.trial_time = trial_time - MLtoCer_ComTime;

end
