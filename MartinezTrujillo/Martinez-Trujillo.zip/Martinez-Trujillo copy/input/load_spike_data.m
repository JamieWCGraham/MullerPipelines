function [x] = load_spike_data(nevfilename, params)

%
% LOAD SPIKE DATA
% 27 August 2019
%
% PARAMETERS
% nevfilename - raw spike data (.nev)
% params.trial_time - ML and cerebus trial time
% params.srate - original sampling rate
%
% OUTPUTS
% x - spike data
%

% load spike data (.nev)

for ii = 1:size(nevfilename,1)        % for loop over number of .nev files 
    clearvars -except ii params nevfilename x 

%    Here we are loading the spike data into the variable spike_data
    
    O = openNEV(nevfilename(ii,:), 'nosave', 'nomat');   % temporary variable
    spike_data = eval( 'O.Data.Spikes' );   % load the spike data into spike_data
    clear O;    % clear the temporary variable
    
    % Here we are initiaizing all of our fields for our spike data
    % structure x 

    if ii == 1
        x.TimeStamp = []; x.Electrode = []; x.Unit = []; x.Waveform = [];
    end

    % Spikes represent the action potential firing of a neuron. For our
    % electrode array, each recorded spike has a correpsonding electrode
    % that recorded the spike, along with a set of neurons specific to the
    % electrode, one or more of which generated the spike. 

    %                       x.TimeStamp
    % x.TimeStamp will contain all of the timestamps for each recorded LFP spike

    %                       x.Electrode 
    % For every spike, x.Electrode will contain the channel number of the
    % corresponding electrode that records the spike. 
    
    %                       x.Unit
    % For every spike, x.Unit will contain the neuron number(s) of the given electrode that generated the
    % spike. 
    
    %                       x.Waveform
    % For every spike, x.Waveform stores the LFP values around the spike,
    % so that we can visualize a plot and also for magnitude information of
    % the LFP spike. 

    
    trlwaitbar = waitbar(0,'Loading spike data');           % implementation of a wait-bar in the GUI
    ind_file = find(cell2mat(params.file_number) == ii);    % this is just to arrange the files in chronological order (sometimes the acquisition does not store them chronologically)
    for ind = ind_file                                      % for loop over all files that contain spike data
        % Progress bar
        waitbar(ind/length(ind_file),trlwaitbar);
        
        % individual trial spike & lfp
        trial_ST = floor((params.trial_time(ind, 8) - params.prefix_dur)*params.srate);     % this is the trial start time
        trial_ET = floor(params.trial_time(ind,9)*params.srate);                            % this is the trial end time
        col_index = find(spike_data.TimeStamp >= trial_ST & spike_data.TimeStamp <= trial_ET);  % storing the indices of all the spike_data inbetween start and end times
        x.TimeStamp = [x.TimeStamp, spike_data.TimeStamp(col_index)];                       % populating the timestamp array with spike_data
        x.Electrode = [x.Electrode, spike_data.Electrode(col_index)];                       % populating the electrode array with spike_data
        x.Unit = [x.Unit, spike_data.Unit(col_index)];                                      % populating the unit array with spike_data
        x.Waveform = [x.Waveform , spike_data.Waveform(:, col_index)];                      % populating the waveform array with spike_data
        
    end
    close(trlwaitbar);  % close the wait bar 
    
end
end
