function [metadata] = get_ODR_ML_metadata(taskstruct, row_idx)

%
% GET MONKEY (BEHAVIORAL) LAB TRIAL TIME AND ID
% 27 August 2019
%
% PARAMETERS
% taskstruct - raw behavioral data (.mat)
% row_idx - row number
%
% OUTPUTS
% metadata - behavioral trials time, outcome and ID
%

% get reference to trial structure
tmp = fieldnames(taskstruct.Trials); tmp = tmp{row_idx,1};
data = eval( sprintf( 'taskstruct.Trials.%s', tmp ) );

% parse metadata
if ~strcmpi('userStoppedTrial', data.OutcomeWord) & ...
        ~any(structfun(@(a)isempty(a), data.TaskEvents))
    trial_time = nan( 1, 7 );
    trial_time(1) = data.SOT_Time;
    trial_time(2) = data.TaskEvents.PreTargetHold;
    trial_time(3) = data.TaskEvents.TargetOnset;
    trial_time(4) = data.TaskEvents.PostTargetHold;
    trial_time(5) = data.TaskEvents.FixPointOffset;
    trial_time(6) = data.TaskEvents.endTrialState;
    trial_time(7) = data.EOT_Time;
else
    trial_time = nan( 1, 7 );
    trial_time(1) = data.SOT_Time;
    trial_time(7) = data.EOT_Time;
end

% save metadata
metadata.trialID = tmp;
metadata.trial_time = trial_time;
metadata.FixPos = [data.FixPoX, data.FixPoY];
metadata.TargPos = [data.TargPoX, data.TargPoY];
metadata.outcome = data.OutcomeWord;

end
