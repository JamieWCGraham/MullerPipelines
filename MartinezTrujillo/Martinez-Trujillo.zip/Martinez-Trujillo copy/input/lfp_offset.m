function [offset] = lfp_offset(nsxfilename)

%
% COMPUTE NUMBER OF RECORDING WHICH SHOULD BE DISCARDED AT THE BEGINING OF LFP DATA
% 27 August 2019
%
% PARAMETERS
% nsxfilename - raw lfp data (.ns6)
%
% OUTPUTS
% offset - number of initial recordings in raw lfp data (.ns6) which should be discarded
%

% load lfp data (.ns6)
lfp_data = openNSx(nsxfilename, 'c:1:1');

% if the first recording session is larger than 10 second, session one should be use otherwise use second recording  
if size(lfp_data.Data{1}, 2) > 10*30000
    offset =  0;
else
    offset = size(lfp_data.Data{1}, 2);
end

end
