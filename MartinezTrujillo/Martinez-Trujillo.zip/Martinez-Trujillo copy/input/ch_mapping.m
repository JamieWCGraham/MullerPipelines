function [channel_map] = ch_mapping(subject, nsp, root_dir, user_inputs)

%
% SET CHENNEL MAPPING
% 13 September 2019
%
% PARAMETERS
% subject - monkey name (buzz/theo)
% nsp - ventral/dorsal channel array (0:ventral and 1:dorsal)
%
% OUTPUTS
% channel_map - channel map
% 
    

% This following block of the code conditionally loads data depending on the subject name and nsp value 
% inputted into the function ch_mapping


if nsp == 0
        filename = user_inputs.subject_name + 'VentralArrayData.mat';
        data = load(sprintf('%s/metadata/%s', root_dir, filename)); 
        data = data.arrayMap;
elseif nsp == 1
        filename = user_inputs.subject_name + 'DorsalArray_Data.mat';
        data = load(sprintf('%s/metadata/%s', root_dir, filename)); 
        data = data.arrayMap;
end

% Here are initializing the output of this function as a 10 by 10 matrix of 
% nan values

channel_map = nan(10, 10);

% In this data, each electrode in a given array has a corresponding channel
% number that is used to identify the electrode.

% This for loop iterates over the number of electrodes, and iteratively
% stores the channel number corresponding to each electrode in the array.

for ii = 1:length(data.ElecNum)
    channel_map(10 - data.Row(ii), data.Column(ii) + 1) = data.ChanNum(ii);
end

% The values of the final channel_map array correspond to the physical positions of
% all electrodes on the physical electrode array on the monkey brain.

% That is, say we had a simplified 2 by 2 electrode array, and 4 channels,
% each corresponding to a given electrode. If channel_map was 

%       1       2 
%       3       4 

%       This expresses that when the electrode array is placed on the
%       monkey brain, the channel-1 electrode is physically in the top left corner of
%       the array, the channel-2 is top right, the channel-3 is bottom left
%       and the channel-4 is bottom right. 


end

