%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     %
% Processing raw data of WM 1         %
% Maryam Mofrad + Lyle Muller         %
% 24 August 2019 
% Documentation by Jamie Graham
%                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 0. Clearing Variables and Adding Paths to the MATLAB Directory. You
% should edit the 'addpath' lines below to isolate your 'input' folder and
% also the NPMK (Neural Processing MATLAB Kit) folder as well. 


clearvars; clc
addpath( './input' );
addpath(genpath('./input/NPMK'));

user_inputs = struct();
user_inputs.recording_year = input("Session Recording Year (YYYY)");
user_inputs.recording_date = input("Session Recording Date (MMDD, eg. Christmas 1225)");
user_inputs.task_number = input("Task Number (1,2, or 3)");
user_inputs.subject_name = string(input("Subject Name (Buzz,etc.)"));

% 1. Defining experiment type, and defining recording sessions.

% parameters 
params.exp_type = "3D"; % "ODR", "3D"     % This line sets the type of experiment as a string

total_date = sprintf('%d%d',user_inputs.recording_year,user_inputs.recording_date);
recording_sessions = {total_date};         % This sets the ID('s) of the experiment recording session(s)



% 2. Here we process the raw data for all of our recording sessions 

for ii = 1:length(recording_sessions)       % Iterating over all the recording sessions 
    
    params.subject = user_inputs.subject_name; % ('buzz', etc)     % Monkey names... 
    params.session = recording_sessions{ii};        % In this loop, set the current session to the ii'th recording session. 
    params.nbr_sec = 6;                             % This parameter is 'number of sections'. Since the raw data is large, we must split it into 6 sections
    params.Fs = 1000;                               % This parameter is 'sampling frequency'. I think this is after down-sampling.
    params.prefix_dur = 2;                          % This is a 'buffer time'.
    params.task_number_final = user_inputs.task_number;
    root_dir = ["./RawData", ...
        "./output"]; % [raw data, output], here we are specifying our root directory
    


    % 3. LOAD RAW DATA 

    % Now that we have merged the data from the CEREBUS and the MLM for this given session-- 
    % we can now process and load the data into our MATLAB workspace. 

    % Process Raw Data
    [metadata] = load_wm1_rawdata(params, root_dir, user_inputs);   % look at this function now, it's in the 'input' folder

end